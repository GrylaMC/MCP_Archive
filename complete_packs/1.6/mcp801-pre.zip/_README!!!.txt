
Totally unfinished, unsupported preview

if you can't get this to work, just delete it completely and wait for the final thing
ABSOLUTELY NO SUPPORT GIVEN OR QUESTIONS ANSWERED BY US !!!

THIS IS FOR 1.6 - NOT FOR 1.6.1 or later version !!!!!

copy server jar into jars folder, rename it to minecraft_server.jar
copy client jar into jars/bin folder, rename it to minecraft.jar
copy assets folder from your .minecraft into jars folder
