#!/bin/bash
python runtime/reobfuscate.py conf/mcp.cfg
