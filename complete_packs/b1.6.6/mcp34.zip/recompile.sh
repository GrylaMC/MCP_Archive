#!/bin/bash
python runtime/recompile.py conf/mcp.cfg
