#!/bin/bash

MCPVERSION="2.0"

MCPDIR=`pwd`
MCPLOG="$MCPDIR/logs/minecraft_compile.log"

MCSRC="sources/minecraft"
MCBIN="$MCPDIR/bin/minecraft"
MCSSRC="sources/minecraft_server"
MCSBIN="$MCPDIR/bin/minecraft_server"

MCJARS="$MCPDIR/jars/bin"
MCJAR="$MCJARS/minecraft.jar"
MCJI="$MCJARS/jinput.jar"
MCJGL="$MCJARS/lwjgl.jar"
MCJGLU="$MCJARS/lwjgl_util.jar"

MCCP="$MCJAR:$MCJI:$MCJGL:$MCJGLU"

MCSTART="patches/Start.java"
MCEO="patches/fb.java"

echo "=== Minecraft Coder Pack $MCPVERSION ==="

mkdir $MCBIN 2>/dev/null
mkdir $MCSBIN 2>/dev/null

echo "Compiling Minecraft"
echo "*** Compiling Minecraft" >> $MCPLOG
javac -g -verbose -classpath $MCCP -sourcepath $MCSRC -d $MCBIN $MCSRC/net/minecraft/src/*.java $MCSRC/net/minecraft/client/*.java 2>> $MCPLOG

echo "Compiling Minecraft Start Class"
echo "*** Compiling Minecraft Starter" >> $MCPLOG
javac -g -verbose -classpath $MCCP:$MCBIN -d $MCBIN $MCSTART 2>> $MCPLOG
javac -g -verbose -classpath $MCCP:$MCBIN -d $MCBIN $MCEO 2>> $MCPLOG

echo "Compiling Minecraft Server"
echo "*** Compiling Minecraft Server" >> $MCPLOG
javac -g -verbose -sourcepath $MCSSRC -d $MCSBIN $MCSSRC/net/minecraft/server/*.java $MCSSRC/net/minecraft/src/*.java 2>> $MCPLOG

echo === MCP $MCPVERSION$ recompile script finished ===

