#!/bin/bash

MCPVERSION="2.0"

MCPDIR=`pwd`
MCBIN=$MCPDIR/bin
MCCP=$MCBIN/minecraft_server

echo "=== Minecraft Coder Pack ${MCPVERSION} ==="

cd $MCBIN
java -Xmx1024M -Xms1024M -cp $MCCP net.minecraft.server.MinecraftServer
