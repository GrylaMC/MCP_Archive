#!/bin/bash

MCPVERSION="2.0"

MCPDIR=`pwd`

MCBIN=$MCPDIR/bin/minecraft

MCTEMP=$MCPDIR/temp/minecraft

MCJARS=$MCPDIR/jars/bin
MCJI=$MCJARS/jinput.jar
MCJGL=$MCJARS/lwjgl.jar
MCJGLU=$MCJARS/lwjgl_util.jar

MCCP=$MCBIN:$MCTEMP:$MCJI:$MCJGL:$MCJGLU

MCNAT=$MCPDIR/jars/bin/natives

echo "=== Minecraft Coder Pack ${MCPVERSION} ==="

java -Xmx1024M -Xms1024M -cp $MCCP -Dorg.lwjgl.librarypath=$MCNAT -Dnet.java.games.input.librarypath=$MCNAT Start
