#!usr/bin/python

#Code by ProfMobius, Oct 2010
#You are welcome to do whatever you want with it, as long as you keep the credits.
#Have fun !

import csv
import pprint
import re
import os
import urllib
import glob
import shutil
from optparse import OptionParser

def read_config(filename):
    ff = open(filename, 'r')
    
    renamer_options = { 'class_csv':None,
                        'field_csv':None,
                        'method_csv':None,
                        'server_rgs':None,
                        'client_rgs':None,
                        'server_rgs_out':None,
                        'client_rgs_out':None,
                        'server_src':None,
                        'client_src':None,
                        'package_name':None}
    
    while True:
        buffer = ff.readline()
        
        if not buffer:
            break
            
        buffer = buffer.split('=')

        if buffer[0].strip() in renamer_options:
            renamer_options[buffer[0].strip()] = buffer[1].strip()
        elif buffer[0].strip() == '':
            continue
        else:
            raise KeyError('Unknown keyword in config file : %s'%buffer[0].strip())
            
    for i in renamer_options.keys():
        if not renamer_options[i]:
            raise KeyError('Missing option in config file : %s'%i)
            
    return renamer_options

def read_csv(filename, header_size, fields):
    print '+ Opening file %s for reading.'%filename
    csv_file = csv.reader(open(filename, 'rb'), delimiter=',')
    
    for i in range(header_size):
        csv_file.next()
    
    #We skip the header
    csv_list = []

    while True:
        try:
            line = csv_file.next()
        except:
            break

        if len(line) >= len(fields):
            line_dic   = {}
            
            for j in range(len(line)):
                if not line[j]:
                    line[j] = '*'
            
            for j in range(len(fields)):
                line_dic[fields[j]] = line[j].strip()

            csv_list.append(line_dic)

    return csv_list

def read_rgs(filename):
    
    print '+ Opening file %s for reading.'%filename
    ff = open(filename, 'rb')
    
    options       = []
    class_map     = []
    field_map     = []
    method_map    = []
    classes       = []
    field_pro     = []
    method_pro     = []
    
    class_map_lk     = {}
    field_map_lk     = {}
    method_map_lk    = {}
    classes_lk       = {}
    field_pro_lk     = {}
    method_pro_lk    = {}
    
    keywords      = {'.option':options, '.class_map':class_map, '.field_map':field_map, '.method_map':method_map, '.class':classes, '.field':field_pro, '.method':method_pro}
    options_kw    = ['name']
    class_map_kw  = ['old_name', 'new_name']
    field_map_kw  = ['class', 'old_name', 'new_name']
    method_map_kw = ['class', 'old_name', 'signature', 'new_name']
    method_pro_kw = ['name', 'signature']
    field_pro_kw  = ['name']
    
    EOF = False
    while True:
        buffer = ff.readline()
        
        if not buffer:
            break
        
        buffer = buffer.split(' ')

        #We skip the comments and the empty lines
        if buffer[0][0] != '#' and buffer[0][0] != '\n':
            #Here we strip the \n on the last element of the line
            buffer[-1] = buffer[-1].strip()
            if not buffer[0] in keywords:
                raise KeyError(buffer[0])

            if buffer[0] == '.option':
                keywords[buffer[0]].append({options_kw[0]:buffer[1]})
            if buffer[0] == '.class_map':
                keywords[buffer[0]].append({class_map_kw[0]:buffer[1], class_map_kw[1]:buffer[2]})
                class_map_lk[buffer[1]] = buffer[2]
            if buffer[0] == '.field_map':
                keywords[buffer[0]].append({field_map_kw[0]:'/'.join(buffer[1].split('/')[0:-1]), field_map_kw[1]:buffer[1].split('/')[-1], field_map_kw[2]:buffer[2]})
                field_map_lk[buffer[1]] = buffer[2]
            if buffer[0] == '.method_map':    
                keywords[buffer[0]].append({method_map_kw[0]:'/'.join(buffer[1].split('/')[0:-1]), method_map_kw[1]:buffer[1].split('/')[-1], method_map_kw[2]:buffer[2], method_map_kw[3]:buffer[3]})            
                method_map_lk[buffer[1]] = buffer[3]
            if buffer[0] == '.class':
                keywords[buffer[0]].append({'command':' '.join(buffer[1:])})
            if buffer[0] == '.method':
                keywords[buffer[0]].append({method_pro_kw[0]:buffer[1], method_pro_kw[1]:buffer[2]})
            if buffer[0] == '.field':
                keywords[buffer[0]].append({field_pro_kw[0]:buffer[1]})
                
        
    return class_map_lk, field_map_lk, method_map_lk, keywords

def write_rgs(filename, keywords, class_list, method_list, field_list, conv_name_src, main_pkg_name, data_pkg_name):
    print '+ Writing new obfuscation file %s.'%filename
    
    fo = open(filename, 'w')
    
    package_name = 'net/minecraft/%s/'%main_pkg_name
    data_name    = data_pkg_name
    if data_name[-1] != '/':
        data_name += '/'
    
    #Create mapping for fields and methods
    field_map  = {}
    method_map = {}
    class_map  = {}
    for i in method_list:
        method_map[i[conv_name_src]] = i['new_name']

    for i in class_list:
        class_map[i[conv_name_src]] = i['new_name']
    
    for i in field_list:
        field_map[i[conv_name_src]] = i['new_name']

    fo.write('.option Application\n')
    fo.write('.option Repackage\n')    
    
    fo.write('\n')
    
    fo.write('.repackage_map %s default\n'%data_name[:-1])
    
    fo.write('\n')
    
#    fo.write('.class paulscode/sound/** protected\n')
#    fo.write('.class com/jcraft/** protected\n')
    
#    for option in keywords['.option']:
#        fo.write('.option ' + option['name'] + '\n')
#        #print '.option', option['name']
#    fo.write('\n')

#    for class_  in keywords['.class']:
#        fo.write('.class ' + class_['command'] + '\n')
#        #print '.class', class_['command']
#    fo.write('\n')
    
    for class_  in keywords['.class_map']:
        if class_['new_name'] == '1':
            pass
        else:
            fo.write('.class_map ' + data_name + class_['new_name'] + ' ' + class_['old_name'] + '\n')
        #print '.class_map', class_['new_name'], class_['old_name']
    fo.write('\n')

#    fo.write('.class *\n')
#    fo.write('.class %s**\n'%main_pkg_name)

    for methods_pro in keywords['.method']:
        fo.write('.method %s %s\n'%(methods_pro['name'], methods_pro['signature']))
    fo.write('\n')

#    for field_pro in keywords['.field']:
#        fo.write('.field %s\n'%(field_pro['name']))
#    fo.write('\n')
    
    for class_pro in keywords['.class']:
        fo.write('.class %s\n'%(class_pro['command']))
    fo.write('\n')



    for method in keywords['.method_map']:
        try:
            new_class_name = data_name + class_map[method['class']]
        except KeyError:
            new_class_name = method['class']
        
        try:
            new_method_name = method_map[method['new_name']]
        except KeyError:
            new_method_name = method['new_name']
        
        new_signature = method['signature']
        for i in class_map.keys():
            new_signature = new_signature.replace('L%s;'%i, 'L%s%s;'%(data_name,class_map[i]))
        
        fo.write('.method_map ' + new_class_name + '/' + new_method_name + ' ' + new_signature + ' ' + method['old_name'] + '\n')
        #print '.method_map', new_class_name + '/' + new_method_name, new_signature, method['old_name']
    fo.write('\n')

    for field in keywords['.field_map']:
        try:
            new_class_name = data_name + class_map[field['class']]
        except KeyError:
            new_class_name = field['class']
        
        try:
            new_field_name = field_map[field['new_name']]
        except KeyError:
            new_field_name = field['new_name']
        
        fo.write('.field_map ' + new_class_name + '/' + new_field_name + ' ' + field['old_name'] + '\n')
        #print '.field_map', new_class_name + '/' + new_field_name, field['old_name']
    fo.write('\n')
        
            
def get_fields_names(field_list, field_map_client, field_map_server):

    #fo = open('test.csv', 'w')
    
    for i in field_list:
        if i['client_class_notch'] != '*':
            i['client_name'] = field_map_client[i['client_class_notch'] + '/' + i['client_name_notch']]
        else:
            i['client_name'] = '*'
        if i['server_class_notch'] != '*':            
            i['server_name'] = field_map_server[i['server_class_notch'] + '/' + i['server_name_notch']]
        else:
            i['server_name'] = '*'

        #fo.write('%s,%s,%s,%s,%s,%s\n'% (i['client_class_notch'], i['client_name_notch'], i['client_name'], i['server_class_notch'], i['server_name_notch'], i['server_name']))
        
    #fo.close()
    
def walk_sources(dir, conv_list, conv_name_src, conv_name_trg, print_tag):
    
    for path, dirlist, filelist in os.walk(dir):
        remap_sources(path, conv_list, conv_name_src, conv_name_trg, print_tag)

def remap_sources(dir, conv_list, conv_name_src, conv_name_trg, print_tag):
    
    print '+ Renaming %s in %s.'%(print_tag, dir)
    
    for src_file in glob.glob(os.path.join(dir,'*.java')):
        
        #print "Remaping file %s"%src_file
        
        fi = open(src_file, 'r')
        fo = open(src_file + '.tmp', 'w')
        
        buffer = ''
        while True:
            buffer_line = fi.readline()
            if not buffer_line:
                break

            buffer += buffer_line
        
        for i in conv_list:
            if i[conv_name_src] != '*':
                buffer = buffer.replace(i[conv_name_src], i[conv_name_trg])
        
        
        
        fo.write(buffer)
        
        fi.close()
        fo.close()
        
        shutil.move(src_file + '.tmp', src_file)

def solve_name_collisions(class_list, field_list, method_list):
    print '+ Solving name collisions.'
    
    unique_names = set()
    
    total_col = 0
    
    for i in class_list:
        unique_names.add(i['new_name'])
        
    for i in method_list:
        start_name = i['new_name']
        index = 0
        buffer = i['new_name']
        while buffer in unique_names:
            buffer = i['new_name'] + '_%02d'%index
            index  += 1
        i['new_name'] = buffer
        unique_names.add(i['new_name'])
        
        if i['new_name'] != start_name:
            total_col += 1

    for i in field_list:
        start_name = i['new_name']
        index = 0
        buffer = i['new_name']
        while buffer in unique_names:
            buffer = i['new_name'] + '_%02d'%index
            index  += 1            
        i['new_name'] = buffer
        unique_names.add(i['new_name'])
        
        if i['new_name'] != start_name:
            total_col += 1   

#Removed because it does freak out the users.
#    if total_col:
#        print '\t- Found %d collisions.'%total_col

def main(options, args):
    config      = read_config(options.conf)
    
    class_list  = read_csv(config['class_csv'],  4,  ['new_name', 'old_clt_name', 'client_name', 'old_srv_name',  'server_name'])
    field_list  = read_csv(config['field_csv'],  3,  ['client_class_notch', 'client_name_notch', 'client_name', 'server_class_notch', 'server_name_notch', 'server_name', 'new_name'])
    method_list = read_csv(config['method_csv'], 8,  ['class_name', 'client_name',  'client_sign','server_name',  'new_name'])    
    
    client_rgs_class, client_rgs_field, client_rgs_method, client_rgs_complete = read_rgs(config['client_rgs'])
    server_rgs_class, server_rgs_field, server_rgs_method, server_rgs_complete = read_rgs(config['server_rgs'])
    
    #get_fields_names(field_list, client_rgs_field, server_rgs_field)
    
    solve_name_collisions(class_list, field_list, method_list)
    
    write_rgs(config['client_rgs_out'], client_rgs_complete, class_list, method_list, field_list, 'client_name', 'client', config['package_name'])
    write_rgs(config['server_rgs_out'], server_rgs_complete, class_list, method_list, field_list, 'server_name', 'server', config['package_name'])
    
    if options.recursive:
        rename_sources = walk_sources
    else:
        rename_sources = remap_sources

    rename_sources(config['client_src'], field_list,  'client_name', 'new_name', 'fields ')
    rename_sources(config['client_src'], method_list, 'client_name', 'new_name', 'methods')
    rename_sources(config['server_src'], field_list,  'server_name', 'new_name', 'fields ')
    rename_sources(config['server_src'], method_list, 'server_name', 'new_name', 'methods')
    
    print ('* ALL DONE *')
    
if __name__ == '__main__':
    usage = "usage: %prog [options]"
    parser = OptionParser(usage=usage)
    parser.add_option("-c", "--conf", dest="conf", default='renamer.conf', help="Configuration file for the renamer. Default to renamer.conf.")  
    parser.add_option("-R", action="store_true", dest="recursive", help="Control if the sources renaming should be recursive or not. Default to no.")   
    (options, args) = parser.parse_args()      
    
    main(options, args)
