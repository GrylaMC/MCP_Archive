#!/bin/bash

MCPVERSION="2.0"
MCPDIR=`pwd`
MCPLOG=$MCPDIR"/logs/minecraft.log"
MCPTOOLS=$MCPDIR"/tools"
MCPTOOLSOSX=$MCPDIR"/tools-osx"
MCPRG="java -cp ${MCPTOOLS}/retroguard.jar RetroGuard"
MCPUNZIP="unzip"
#MCPJR=$MCPTOOLS"/jadretro.exe"
#MCPJAD=$MCPTOOLS"/jad.exe"
MCPJR="java -cp ${MCPTOOLSOSX}/jadretro.jar"
MCPJAD=$MCPTOOLSOSX"/jad"
MCPPATCH="patch"
MCJAR=$MCPDIR"/jars/bin/minecraft.jar"
MCSJAR=$MCPDIR"/jars/minecraft_server.jar"
MCRGJAR=$MCPDIR"/temp/minecraft_rg.jar"
MCRGSCRIPT=$MCPDIR"/conf/minecraft.rgs"
MCRGLOG=$MCPDIR"/logs/minecraft_rg.log"
MCSRGJAR=$MCPDIR"/temp/minecraft_server_rg.jar"
MCSRGSCRIPT=$MCPDIR"/conf/minecraft_server.rgs"
MCSRGLOG=$MCPDIR"/logs/minecraft_server_rg.log"
MCTEMP=$MCPDIR"/temp/minecraft"
MCSTEMP=$MCPDIR"/temp/minecraft_server"
MCJADOUT=$MCPDIR"/sources/minecraft"
MCSJADOUT=$MCPDIR"/sources/minecraft_server"
MCPATCH=$MCPDIR"/patches/minecraft-osx.patch"
MCFINALPATCH=$MCPDIR"/patches/minecraft-final-osx.patch"
MCSPATCH=$MCPDIR"/patches/minecraft_server-osx.patch"

echo "=== Minecraft Coder Pack $MCPVERSION ==="

echo "Deobfuscating minecraft.jar"
echo "*** Deobfuscating minecraft.jar" >> $MCPLOG
$MCPRG $MCJAR $MCRGJAR $MCRGSCRIPT $MCRGLOG >> $MCPLOG

echo "Unpacking minecraft.jar"
echo "*** Unpacking minecraft.jar" >>$MCPLOG
$MCPUNZIP -o $MCRGJAR -d $MCTEMP >>$MCPLOG
rm -r -f $MCTEMP/META-INF/MOJANG_C.*

echo "Fixing minecraft classes"
echo "*** Fixing minecraft classes" >>$MCPLOG
#wine $MCPJR -b $MCTEMP >> $MCPLOG 2>/dev/null
$MCPJR -b $MCTEMP >> $MCPLOG 2>/dev/null

echo "Decompiling minecraft classes"
echo "*** Decompiling minecraft classes" >>$MCPLOG
$MCPJAD -b -d $MCJADOUT -dead -o -r -s .java -stat -v $MCTEMP/*.class 2>>$MCPLOG
$MCPJAD -b -d $MCJADOUT -dead -o -s .java -stat -v "${MCTEMP}/net/minecraft/client/*.class" 2>>$MCPLOG
#wine $MCPJAD -b -d $MCJADOUT -dead -o -r -s .java -stat -v $MCTEMP/*.class 2>>$MCPLOG
#wine $MCPJAD -b -d $MCJADOUT -dead -o -s .java -stat -v "${MCTEMP}/net/minecraft/client/*.class" 2>>$MCPLOG

echo "Repackaging minecraft sources"
echo "*** Repackaging minecraft sources" >>$MCPLOG
cd $MCJADOUT
mkdir -p net/minecraft/client 2>/dev/null
mv Minecraft.java net/minecraft/client
mv MinecraftApplet.java net/minecraft/client
mkdir -p net/minecraft/src 2>/dev/null
echo "package net.minecraft.src;" > package.txt
for file in *.java
do 
	cat package.txt $file > $file"2"
	mv $file"2" $file
	mv $file $MCJADOUT/net/minecraft/src/
done
rm package.txt
cd $MCPDIR
echo "…done"

echo "Patching minecraft sources"
echo "*** Patching minecraft sources" >>$MCPLOG
$MCPPATCH -u -p 0 -i $MCPATCH -d $MCJADOUT

echo "Deobfuscating minecraft_server.jar"
echo "*** Deobfuscating minecraft_server.jar" >> $MCPLOG
$MCPRG $MCSJAR $MCSRGJAR $MCSRGSCRIPT $MCSRGLOG >> $MCPLOG

echo "Unpacking minecraft_server.jar"
echo "*** Unpacking minecraft_server.jar" >>$MCPLOG
$MCPUNZIP -o $MCSRGJAR -d $MCSTEMP >>$MCPLOG

echo "Fixing minecraft_server classes"
echo "*** Fixing minecraft_server classes" >>$MCPLOG
$MCPJR -b $MCSTEMP >> $MCPLOG 2>/dev/null
#wine $MCPJR -b $MCSTEMP >> $MCPLOG 2>/dev/null

echo "Decompiling minecraft_server classes"
echo "*** Decompiling minecraft_server classes" >>$MCPLOG
$MCPJAD -b -d $MCSJADOUT -dead -o -r -s .java -stat -v $MCSTEMP/*.class 2>>$MCPLOG
$MCPJAD -b -d $MCSJADOUT -dead -o -s .java -stat -v "${MCSTEMP}/net/minecraft/server/*.class" 2>>$MCPLOG
#wine $MCPJAD -b -d $MCSJADOUT -dead -o -r -s .java -stat -v $MCSTEMP/*.class 2>>$MCPLOG
#wine $MCPJAD -b -d $MCSJADOUT -dead -o -s .java -stat -v "${MCSTEMP}/net/minecraft/server/*.class" 2>>$MCPLOG

echo "Repackaging minecraft server sources"
echo "*** Repackaging minecraft server sources" >>$MCPLOG
cd $MCSJADOUT
mkdir -p net/minecraft/server 2>/dev/null
mv MinecraftServer.java net/minecraft/server
mkdir -p net/minecraft/src 2>/dev/null
echo "package net.minecraft.src;" > package.txt
for file in *.java
do 
	cat package.txt $file > $file"2"
	mv $file"2" $file
	mv $file $MCSJADOUT/net/minecraft/src/
done
rm package.txt
cd $MCPDIR
echo "…done"

echo "Patching minecraft_server sources"
echo "*** Patching minecraft_server sources" >>$MCPLOG
$MCPPATCH -u -p 1 --ignore-whitespace -i $MCSPATCH -d $MCSJADOUT >>$MCPLOG

echo "Getting fresh .csv"
echo "*** Getting fresh .csv" >>$MCPLOG
python tools-osx/get_csv.py

echo "Renaming methods and fields"
echo "*** Renaming methods and fields"
python tools-osx/renamer_v1.py -R -c conf/renamer.conf
echo "…done"